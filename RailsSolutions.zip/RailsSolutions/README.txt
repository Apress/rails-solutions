Rails Solutions: Ruby on Rails Made Easy
Source Code
Last Updated: December 16, 2006


1. Before running this code, make sure you have Rails installed. 

2. To run the code, run 'ruby script/server' in the respective railslist folder for whatever chapter you want to work with.

For more information on Rails Solutions, check out http://railssolutions.com.

Have fun learning Rails!

Justin Williams
justin@secondgearllc.com
http://secondgearllc.com