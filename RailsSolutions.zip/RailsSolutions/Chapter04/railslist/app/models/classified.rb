class Classified < ActiveRecord::Base
end
