def returnFoo 
	bar = “Ramone, bring me my cup.” 
	return bar 
end 

puts returnFoo 
