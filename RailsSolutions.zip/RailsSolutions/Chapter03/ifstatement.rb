age = 40 
if age < 12 
  puts "You are too young to play" 
elsif age < 30 
  puts "You can play for the normal price" 
elsif age == 35 
  puts "You can play for free" 
elsif age < 65 
  puts "You get a senior discount" 
else 
  puts "You are too old to play" 
end 
