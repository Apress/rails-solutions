def helloPerson(name) 
	result =  "Hello, " + name 
	return result 
end 

puts helloPerson("Justin")