clock = 0 
while clock < 90 
  puts "I kicked the ball to my team mate in the " + count.to_s + " minute of the match." 
  clock += 1 
end 
