class Student 
  def login_student 
    puts "login_student is running"
  end 
private 
  def delete_students 
    puts "delete_students is running" 
  end 
protected 
  def encrypt_student_password 
    puts "encrypt_student_password is running" 
  end 
end 
